#include <wiringPi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <signal.h>
#include "iotmakers.h"

#define LED1 5 // BCM_GPIO 24
int state1 = 1;
int state2 = 1;
static int local_loop = (0);

static void SigHandler(int sig)
{
	switch(sig)
	{
		case SIGTERM :
		case SIGINT :
			printf("accept signal SIGINT[%d]\n", sig);
			im_stop_service();
			local_loop = (0);
			break;
		default :
			;
	};
	return;
} 
static void set_SigHandler()
{
	signal(SIGINT,   SigHandler);	
	signal(SIGTERM,  SigHandler);	
}

/* ============================
main_sample1.c

- Receiving the control data
	mycb_numdata_handler();
	mycb_strdata_handler();
============================ */
static void mycb_numdata_handler(char *tagid, double numval)
{
	// !!! USER CODE HERE
	//printf("tagid=[%s], val=[%f]\n", tagid, numval);
}

static void mycb_strdata_handler(char *tagid, char *strval)
{
	// !!! USER CODE HERE
	//printf("tagid=[%s], val=[%s]\n", tagid, strval);

	// LED on-off ...
	pinMode(LED1, OUTPUT);
	if(!strcmp(tagid, "LED"))
	{
		if(!strcmp(strval, "ON"))
		{
			printf("tagid=[%s], val=[%s]\n", tagid, strval);
			digitalWrite(LED1, 1); // On
			
			state1 = 0;  // local case...
		}
		else if(!strcmp(strval,"OFF"))
		{
			printf("tagid=[%s], val=[%s]\n", tagid, strval);
		    digitalWrite(LED1, 0); // Off
		    
  			state1 = 0;  // local case...  
		}
	}
}

/* ============================
main_sample1.c

- Sending the collection data
	im_send_numdata();
	im_send_strdata();
============================ */
int main(int argc, char* argv[])
{
	int i;
	int rc;

	set_SigHandler();
	rc = im_init_with_config_file("./config.txt");
	if(rc < 0)	
	{
		printf("fail im_init()\n");
		return -1;
	}

	im_set_loglevel(LOG_LEVEL_DEBUG);
	im_set_numdata_handler(mycb_numdata_handler);
	im_set_strdata_handler(mycb_strdata_handler);

	rc = im_start_service();
	if(rc < 0)	
	{
		printf("fail im_start_service()\n");
		im_release();
		return -1;
	}

    // Raspberry pi wiringPiSetup...
	if(wiringPiSetup() == -1) exit(1); 

	local_loop = (1);
	while(local_loop == (1)) 
	{
			if ( state1 < 1  )	
			{
				printf("process end !\n");
				//delay(5000);		
				
				break;
			}	
	
			if ( state2 == 1  )	
			{
						if(!strcmp(argv[1], "on"))
						{
								im_send_numdata("Temp", 100, 0);
								printf("your value= %s\n", argv[1]);
						 }
						 else if(!strcmp(argv[1], "off"))
						 {
								im_send_numdata("Temp", 200, 0);
								printf("your value= %s\n", argv[1]);							 
						 }
						 else
						 {
								im_send_numdata("Temp", 300, 0);
								printf("your value = %s\n", argv[1]);		
								
					  			state1 = 0;  // local case...  					 
						 }
				
				        state2 = 0; // local case ...
			}
     }

	//printf("im_stop_service()\n");
	im_stop_service();

	//printf("im_release()\n");
	im_release();
		    		    
	return 0;
}
