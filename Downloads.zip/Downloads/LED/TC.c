#include <stdio.h>
#include <wiringPi.h>

#define TC1 4 // wPi 4, BCM_GPIO 23

int main(void)
{
    // Raspberry pi wiringPiSetup ...
	if(wiringPiSetup() == -1) return 1; 

	// TC1 on-off ...
	pinMode(TC1, INPUT);

	for(;;)
	{
		if(digitalRead(TC1)==0)
		{
			printf("Not Detect !!\n");
		}
		else
		{
			printf("Detected !!\n");
		}

		delay(1000); //ms
	}	

	return 0;
}

// gcc -o TC TC.c -lwiringPi
// sudo ./TC
