#include <stdio.h>
#include <wiringPi.h>

#define LED1 5 // wPi 5, BCM_GPIO 24

int main(void)
{
    // Raspberry pi wiringPiSetup ...
	if(wiringPiSetup() == -1) return 1; 

	// LED on-off ...
	pinMode(LED1, OUTPUT);

	for(;;)
	{
		digitalWrite(LED1, 1); // On
		delay(1000); //ms

	    digitalWrite(LED1, 0); // Off
		delay(1000); //ms
	}	

	return 0;
}

// gcc -o LED LED.c -lwiringPi
// sudo ./LED



