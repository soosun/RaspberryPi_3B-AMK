#!/usr/bin/env python
# -*- coding: utf-8 -*-


import Adafruit_DHT as dht
import time


def checkCommand(result):
    print("현재 온도는 ?")

    humidity, temperature = dht.read_retry(11, 4)
    text = result
    print("현재 온도는 ?")

    if text.find("온도 알려줘") >= 0:
        print("현재 온도는 {} 도 입니다 ".format(temperature))
        return("현재 온도는 {} 도 입니다 ".format(temperature))
    
    elif text.find("습도 알려줘") >= 0:
        print("현재 습도는 {} 퍼센트 입니다 ".format(humidity))
        return("현재 습도는 {} 퍼센트 입니다 ".format(humidity))
    else:
        return("정확한 명령을 말해주세요")


def main():
    checkCommand("온도 알려줘")


if __name__ == '__main__':
    main()