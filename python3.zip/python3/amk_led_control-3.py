from tkinter import *
import subprocess
import time

state1 = 1
root = Tk()
root.title("Event Test")
root.geometry("100x100+300+300")

def callback():
    global state1
    if state1 == 1:
        subprocess.SW_HIDE = 1
        proc = subprocess.Popen(['/home/pi/Downloads/CSDK/test_away/tt_away_on', 'on']).wait()
#        proc = subprocess.Popen(['/home/pi/Downloads/CSDK/test_local/tt_local_on', 'on']).wait()
        if proc==1:
            print('running error !')
        else:
            print('LED_on ok !\n\n')
        state1 = 0
    elif state1 == 0:
        subprocess.SW_HIDE = 1
        proc = subprocess.Popen(['/home/pi/Downloads/CSDK/test_away/tt_away_on', 'off']).wait()
#        proc = subprocess.Popen(['/home/pi/Downloads/CSDK/test_local/tt_local_on', 'off']).wait()
        if proc==1:
            print('running error !')
        else:
            print('LED_off ok !\n\n')
        state1 = 1
    else:
        print("button no")     
	
button = Button(root, text = "LED on/off!", width=10, command = callback)
button.pack(padx = 10, pady = 30)

root.mainloop()
