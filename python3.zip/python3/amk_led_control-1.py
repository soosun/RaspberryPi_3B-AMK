from tkinter import *
import RPi.GPIO as GPIO
import time

root = Tk()
root.title("Event Test")
root.geometry("100x100+300+300")

LED = 24 
GPIO.setmode(GPIO.BCM)
GPIO.setup(LED, GPIO.OUT)
    
def callback():
	print("button clicked")

	GPIO.output(LED, GPIO.HIGH)
	time.sleep(1.5)
			
	GPIO.output(LED, GPIO.LOW)
	
button = Button(root, text = "LED on/off!", width=10, command = callback)
button.pack(padx = 10, pady = 30)

root.mainloop()
GPIO.cleanup()
