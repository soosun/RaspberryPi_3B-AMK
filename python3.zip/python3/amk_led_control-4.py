#!/usr/bin/env python
from __future__ import print_function

import time
import ex1_kwstest as kws
import ex2_getVoice2Text as gv2t
import ex4_getText2VoiceStream as tts
import MicrophoneStream as MS
import sys, os, subprocess
import RPi.GPIO as GPIO

def ledControl(result):
    text = result
            
    if text.find("켜") >= 0:
        print("불이 켜집니다.")
        subprocess.SW_HIDE = 1
        proc = subprocess.Popen(['/home/pi/Downloads/CSDK/test_away/tt_away_on', 'on']).wait()
#        proc = subprocess.Popen(['/home/pi/Downloads/CSDK/test_local/tt_local_on', 'on']).wait()
        if proc==1:
            print('running error !')
        else:
            print('LED_on ok !\n\n')
    
        return("불을 킵니다.")

    elif text.find("꺼") >= 0:
        print("불이 꺼집니다.")
        subprocess.SW_HIDE = 1
        proc = subprocess.Popen(['/home/pi/Downloads/CSDK/test_away/tt_away_on', 'off']).wait()
#        proc = subprocess.Popen(['/home/pi/Downloads/CSDK/test_local/tt_local_on', 'off']).wait()
        if proc==1:
            print('running error !')
        else:
            print('LED_off ok !\n\n')
            
        return("불을 끕니다.")

    else:
        return("정확한 명령을 말해주세요")

def main():
	#Example7 KWS+STT

    KWSID = ['기가지니', '지니야', '친구야', '자기야']
    while 1:
        recog=kws.test(KWSID[1])
        if recog == 200:
            print('KWS Dectected ...\n Start STT...')
            text = gv2t.getVoice2Text()
            print('Recognized Text: '+ text)
            tts.getText2VoiceStream(ledControl(text), "result_TTS.wav")
            MS.play_file("result_TTS.wav")
            time.sleep(2)

        else:
            print('KWS Not Dectected ...')
    
if __name__ == '__main__':
    try:
        main()

    finally:
        GPIO.cleanup()
        
